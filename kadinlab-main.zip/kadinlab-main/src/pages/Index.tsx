
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layouts/DashboardLayout";
import { supabase } from "@/integrations/supabase/client";
import { StatsOverview } from "@/components/stats/StatsOverview";
import { ClientSearch } from "@/components/cliente/ClientSearch";
import { ClientesTable } from "@/components/cliente/ClientesTable";
import { Button } from "@/components/ui/button";
import { Clock, RefreshCw } from "lucide-react";
import { calcularDiasRestantes } from "@/components/cliente/utils";
import { Database } from "@/integrations/supabase/types";
import { useToast } from "@/components/ui/use-toast";

type Cliente = Database["public"]["Tables"]["clientes"]["Row"] & {
  responsavel: {
    nome: string;
    telefone: string;
  } | null;
};

const fetchClientes = async () => {
  console.log("Fetching clientes...");
  const { data, error } = await supabase
    .from("clientes")
    .select("*")
    .eq('status', 'Ativo')
    .order("nome");
  
  if (error) {
    console.error("Error fetching clientes:", error);
    throw error;
  }
  console.log("Clientes data:", data);
  return data as Cliente[];
};

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filtrarDiasRestantes, setFiltrarDiasRestantes] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const { toast } = useToast();

  const { data: clientes = [], isLoading, error, refetch } = useQuery({
    queryKey: ["clientes"],
    queryFn: fetchClientes,
  });

  const handleSyncFacebookData = async () => {
    try {
      setIsSyncing(true);
      const { data, error } = await supabase.functions.invoke('sync-facebook-data');
      
      if (error) throw error;
      
      await refetch(); // Recarrega os dados após a sincronização
      
      if (data.resultados) {
        toast({
          title: "Sincronização concluída",
          description: `Total: ${data.resultados.total}
            Processados: ${data.resultados.processados}
            Erros: ${data.resultados.erros}`,
        });

        // Se houver erros, mostrar toast com detalhes
        if (data.resultados.erros > 0) {
          const erros = data.resultados.detalhes.filter(d => d.includes('Erro'));
          toast({
            variant: "destructive",
            title: "Alguns clientes não foram sincronizados",
            description: erros.join('\n'),
          });
        }
      } else {
        toast({
          title: "Sincronização concluída",
          description: "Os dados foram atualizados com sucesso!",
        });
      }
    } catch (err) {
      console.error('Erro na sincronização:', err);
      toast({
        variant: "destructive",
        title: "Erro na sincronização",
        description: "Não foi possível atualizar os dados do Facebook.",
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const filteredClientes = clientes.filter((cliente) =>
    cliente.nome?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const clientesBoleto = filteredClientes
    .filter((cliente) => cliente.cobranca_meta === "Boleto")
    .filter((cliente) => {
      if (filtrarDiasRestantes) {
        const dias = calcularDiasRestantes(cliente.creditos, cliente.orcamento_mensal);
        return dias <= 5;
      }
      return true;
    })
    .sort((a, b) => {
      // Primeiro critério: dias restantes
      const diasA = calcularDiasRestantes(a.creditos, a.orcamento_mensal);
      const diasB = calcularDiasRestantes(b.creditos, b.orcamento_mensal);
      
      if (diasA !== diasB) {
        return diasA - diasB;
      }
      
      // Segundo critério: quantidade de créditos (do menor para o maior)
      const creditosA = a.creditos || 0;
      const creditosB = b.creditos || 0;
      return creditosA - creditosB;
    });

  const clientesCartao = filteredClientes.filter(
    (cliente) => cliente.cobranca_meta === "Cartão"
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Gestão de Orçamentos</h1>
          <Button
            onClick={handleSyncFacebookData}
            disabled={isSyncing}
            className="w-full md:w-auto"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Sincronizando...' : 'Sincronizar com Facebook'}
          </Button>
        </div>

        {/* Stats Overview */}
        <StatsOverview 
          totalClientes={clientes.length}
          totalBoleto={clientesBoleto.length}
          totalCartao={clientesCartao.length}
        />

        {/* Search and Filter */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <ClientSearch 
            value={searchQuery}
            onChange={setSearchQuery}
          />
          <Button
            variant={filtrarDiasRestantes ? "default" : "outline"}
            onClick={() => setFiltrarDiasRestantes(!filtrarDiasRestantes)}
            className="w-full sm:w-auto"
          >
            <Clock className="mr-2 h-4 w-4" />
            {filtrarDiasRestantes ? "Mostrar Todos" : "Filtrar ≤ 5 dias"}
          </Button>
        </div>

        {/* Clients Tables */}
        {isLoading ? (
          <div>Carregando...</div>
        ) : error ? (
          <div className="text-destructive">Erro ao carregar dados: {error.message}</div>
        ) : filteredClientes.length === 0 ? (
          <div>Nenhum cliente encontrado</div>
        ) : (
          <>
            <ClientesTable clientes={clientesBoleto} title="Clientes Boleto" />
            <ClientesTable clientes={clientesCartao} title="Clientes Cartão" />
          </>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Index;
