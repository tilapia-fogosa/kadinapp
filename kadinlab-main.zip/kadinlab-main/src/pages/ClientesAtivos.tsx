
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { MessageSquare, ExternalLink } from "lucide-react";
import { DashboardLayout } from "@/components/layouts/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Status = "Ativo" | "Onboarding" | "Desistente" | "Fechado" | "Desligamento Programado";
type CobrancaMeta = "Boleto" | "Cartão" | "Não faz trafego";

interface Cliente {
  id: number;
  nome: string | null;
  status: Status;
  mensalidade_fee: number | null;
  orcamento_mensal: number | null;
  cnpj: number | null;
  responsavel: {
    nome?: string;
    email?: string;
    telefone?: string;
    [key: string]: string | undefined;
  } | null;
  ad_acc_id: number | null;
  cidade: string | null;
  estado: string | null;
  cobranca_meta: CobrancaMeta | null;
  created_at: string;
  inicio_do_contrato: string | null;
  fim_do_contrato: string | null;
}

const fetchClientesAtivos = async () => {
  console.log("Fetching active clients...");
  const { data, error } = await supabase
    .from("clientes")
    .select("*")
    .eq('status', 'Ativo')
    .order("nome");
  
  if (error) {
    console.error("Error fetching clients:", error);
    throw error;
  }
  console.log("Fetched data:", data);
  return data as Cliente[];
};

const ClientesAtivos = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const queryClient = useQueryClient();

  const { data: clientes = [], isLoading, error } = useQuery({
    queryKey: ["clientes-ativos"],
    queryFn: fetchClientesAtivos,
  });

  const filteredClientes = clientes.filter((cliente) =>
    cliente.nome?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const updateCliente = async (id: number, updates: { status?: Status; mensalidade_fee?: number | null; orcamento_mensal?: number | null }) => {
    console.log("Updating client:", id, "with:", updates);
    try {
      const { error } = await supabase
        .from("clientes")
        .update(updates)
        .eq("id", id);

      if (error) {
        console.error("Supabase error:", error);
        throw error;
      }
      
      console.log("Update successful, invalidating queries...");
      await queryClient.invalidateQueries({ queryKey: ["clientes-ativos"] });
      toast.success("Cliente atualizado com sucesso!");
    } catch (error) {
      console.error("Error updating cliente:", error);
      toast.error("Erro ao atualizar cliente");
    }
  };

  const handleStatusChange = async (clienteId: number, newStatus: Status) => {
    console.log("Status change:", clienteId, newStatus);
    await updateCliente(clienteId, { status: newStatus });
  };

  const handleValueChange = (clienteId: number, field: "mensalidade_fee" | "orcamento_mensal", value: string) => {
    const numericValue = value === "" ? null : parseFloat(value);
    if (isNaN(numericValue) && value !== "") return;
    
    console.log("Value change:", clienteId, field, numericValue);
    updateCliente(clienteId, { [field]: numericValue });
  };

  const formatCurrency = (value: number | null) => {
    if (value === null) return "";
    return value.toString();
  };

  const openWhatsApp = (telefone: string) => {
    const cleanPhone = telefone.replace(/\D/g, '');
    window.open(`https://wa.me/${cleanPhone}`, '_blank');
  };

  const openFacebookAds = (adAccId: number) => {
    window.open(
      `https://business.facebook.com/billing_hub/accounts/details?asset_id=${adAccId}&business_id=1556485854475350&placement=ads_manager`,
      '_blank'
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Clientes Ativos</h1>
        </div>

        <div className="flex w-full max-w-sm items-center space-x-2">
          <Input
            type="search"
            placeholder="Buscar cliente..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-9"
          />
        </div>

        {isLoading ? (
          <div>Carregando...</div>
        ) : error ? (
          <div className="text-red-500">Erro ao carregar dados</div>
        ) : filteredClientes.length === 0 ? (
          <div>Nenhum cliente encontrado</div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Franqueado</TableHead>
                  <TableHead>CNPJ</TableHead>
                  <TableHead>Contato</TableHead>
                  <TableHead>Mensalidade</TableHead>
                  <TableHead>Orçamento Mensal</TableHead>
                  <TableHead className="text-center">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClientes.map((cliente) => (
                  <TableRow key={cliente.id}>
                    <TableCell className="font-medium">{cliente.nome}</TableCell>
                    <TableCell>
                      <Select
                        value={cliente.status}
                        onValueChange={(value) => handleStatusChange(cliente.id, value as Status)}
                      >
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder={cliente.status} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Ativo">Ativo</SelectItem>
                          <SelectItem value="Onboarding">Onboarding</SelectItem>
                          <SelectItem value="Desistente">Desistente</SelectItem>
                          <SelectItem value="Fechado">Fechado</SelectItem>
                          <SelectItem value="Desligamento Programado">
                            Desligamento Programado
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>{cliente.responsavel?.nome || '-'}</TableCell>
                    <TableCell>{cliente.cnpj || '-'}</TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p>{cliente.responsavel?.telefone || '-'}</p>
                        <p>{cliente.responsavel?.email || '-'}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Input
                        type="text"
                        value={formatCurrency(cliente.mensalidade_fee)}
                        onChange={(e) => 
                          handleValueChange(cliente.id, "mensalidade_fee", e.target.value)
                        }
                        className="w-28"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="text"
                        value={formatCurrency(cliente.orcamento_mensal)}
                        onChange={(e) =>
                          handleValueChange(cliente.id, "orcamento_mensal", e.target.value)
                        }
                        className="w-28"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-center gap-2">
                        {cliente.responsavel?.telefone && (
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => openWhatsApp(cliente.responsavel.telefone!)}
                            title="Abrir WhatsApp"
                          >
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                        )}
                        {cliente.ad_acc_id && (
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => openFacebookAds(cliente.ad_acc_id!)}
                            title="Abrir Facebook Ads"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ClientesAtivos;
