
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface StatsOverviewProps {
  totalClientes: number;
  totalBoleto: number;
  totalCartao: number;
}

export function StatsOverview({ totalClientes, totalBoleto, totalCartao }: StatsOverviewProps) {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Clientes Ativos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-primary">{totalClientes}</div>
        </CardContent>
      </Card>
      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Clientes Boleto</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-primary">{totalBoleto}</div>
        </CardContent>
      </Card>
      <Card className="border-secondary/20">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Clientes Cartão</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-secondary">{totalCartao}</div>
        </CardContent>
      </Card>
    </div>
  );
}
