
import { Database, Users, UserCheck } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

const menuItems = [
  {
    title: "Gestão de Orçamentos",
    url: "/",
    icon: Database,
  },
  {
    title: "Clientes Ativos",
    url: "/clientes-ativos",
    icon: UserCheck,
  },
  {
    title: "Todos os Clientes",
    url: "/todos-clientes",
    icon: Users,
  },
];

export function AppSidebar() {
  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <div className="flex items-center justify-center py-6">
            <img
              src="/lovable-uploads/110b9026-741b-47ee-a288-f94104b974c0.png"
              alt="Logo Supera"
              className="h-8 dark:brightness-0 dark:invert"
            />
          </div>
          <SidebarGroupLabel>Supera</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <a href={item.url}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
