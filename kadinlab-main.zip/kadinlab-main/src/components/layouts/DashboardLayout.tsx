
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/layouts/AppSidebar";

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50 dark:bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col">
          <main className="flex-1 p-6 overflow-x-hidden">
            {children}
          </main>
          <footer className="p-4 border-t border-border flex items-center justify-center">
            <img
              src="/lovable-uploads/110b9026-741b-47ee-a288-f94104b974c0.png"
              alt="Logo Supera"
              className="h-6 dark:brightness-0 dark:invert"
            />
          </footer>
        </div>
      </div>
    </SidebarProvider>
  );
}
