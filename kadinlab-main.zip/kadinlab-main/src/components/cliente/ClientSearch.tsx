
import { Input } from "@/components/ui/input";

interface ClientSearchProps {
  value: string;
  onChange: (value: string) => void;
}

export function ClientSearch({ value, onChange }: ClientSearchProps) {
  return (
    <div className="flex w-full max-w-sm items-center space-x-2">
      <Input
        type="search"
        placeholder="Buscar unidade..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 focus-visible:ring-primary"
      />
    </div>
  );
}
