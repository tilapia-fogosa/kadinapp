
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { MessageSquare, CreditCard, Receipt, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatCurrency, calcularDiasRestantes, openWhatsApp, openFacebookAds } from "./utils";

interface Cliente {
  id: number;
  nome: string;
  responsavel?: {
    nome: string;
    telefone: string;
  };
  creditos: number | null;
  ultimo_envio: string | null;
  orcamento_mensal: number | null;
  ad_acc_id: number | null;
}

interface ClientesTableProps {
  clientes: Cliente[];
  title: "Clientes Boleto" | "Clientes Cartão";
}

export function ClientesTable({ clientes, title }: ClientesTableProps) {
  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {title === "Clientes Boleto" ? (
            <Receipt className="h-5 w-5 text-primary" />
          ) : (
            <CreditCard className="h-5 w-5 text-secondary" />
          )}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Franqueado</TableHead>
                {title === "Clientes Boleto" && (
                  <>
                    <TableHead className="text-right">Créditos</TableHead>
                    <TableHead>Último Envio</TableHead>
                    <TableHead className="text-right">Dias Restantes</TableHead>
                  </>
                )}
                <TableHead className="text-right">Orçamento Mensal</TableHead>
                <TableHead className="text-center">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clientes.map((cliente) => {
                const diasRestantes = calcularDiasRestantes(cliente.creditos, cliente.orcamento_mensal);
                return (
                  <TableRow key={cliente.id}>
                    <TableCell className="font-medium">{cliente.nome}</TableCell>
                    <TableCell>{cliente.responsavel?.nome || '-'}</TableCell>
                    {title === "Clientes Boleto" && (
                      <>
                        <TableCell className="text-right">{formatCurrency(cliente.creditos)}</TableCell>
                        <TableCell>
                          {cliente.ultimo_envio 
                            ? format(new Date(cliente.ultimo_envio), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                            : "-"}
                        </TableCell>
                        <TableCell className="text-right">{diasRestantes} dias</TableCell>
                      </>
                    )}
                    <TableCell className="text-right">
                      {formatCurrency(cliente.orcamento_mensal)}
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-center gap-2">
                        {cliente.responsavel?.telefone && (
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => openWhatsApp(cliente.responsavel.telefone, cliente.creditos, diasRestantes)}
                            title="Abrir WhatsApp"
                            className="hover:bg-primary/10 hover:text-primary"
                          >
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                        )}
                        {cliente.ad_acc_id && (
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => openFacebookAds(cliente.ad_acc_id)}
                            title="Abrir Facebook Ads"
                            className="hover:bg-secondary/10 hover:text-secondary"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
