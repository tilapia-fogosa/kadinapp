
export const formatCurrency = (value: number | null) => {
  if (!value) return "-";
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

export const calcularDiasRestantes = (creditos: number | null, orcamentoMensal: number | null) => {
  if (!creditos || !orcamentoMensal || orcamentoMensal === 0) return 0;
  return Math.round((creditos / (orcamentoMensal / 30)));
};

export const openWhatsApp = (telefone: string, creditos: number | null, diasRestantes: number) => {
  const cleanPhone = telefone.replace(/\D/g, '');
  const mensagem = `Olá! Segue o boleto do facebook. Hoje, temos R$${creditos?.toFixed(2)} na conta de anúncios, restam ${diasRestantes} dias para acabarem os créditos!`;
  const encodedMessage = encodeURIComponent(mensagem);
  window.open(`https://wa.me/${cleanPhone}?text=${encodedMessage}`, '_blank');
};

export const openFacebookAds = (adAccId: number) => {
  window.open(
    `https://business.facebook.com/billing_hub/accounts/details?asset_id=${adAccId}&business_id=1556485854475350&placement=ads_manager`,
    '_blank'
  );
};
