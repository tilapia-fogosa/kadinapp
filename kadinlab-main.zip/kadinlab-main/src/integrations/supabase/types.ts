export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      clientes: {
        Row: {
          ad_acc_id: number | null
          cidade: string | null
          cnpj: number | null
          cobranca_meta: Database["public"]["Enums"]["Cobrança Meta"] | null
          created_at: string
          creditos: number | null
          estado: string | null
          fim_do_contrato: string | null
          id: number
          inicio_do_contrato: string | null
          mensalidade_fee: number | null
          nome: string | null
          orcamento_mensal: number | null
          preco_do_lead_15d: number | null
          preco_do_lead_3d: number | null
          preco_do_lead_7d: number | null
          prioridade: Database["public"]["Enums"]["Prioridade"] | null
          responsavel: Json | null
          status: Database["public"]["Enums"]["Status"]
          ultimo_envio: string | null
        }
        Insert: {
          ad_acc_id?: number | null
          cidade?: string | null
          cnpj?: number | null
          cobranca_meta?: Database["public"]["Enums"]["Cobrança Meta"] | null
          created_at?: string
          creditos?: number | null
          estado?: string | null
          fim_do_contrato?: string | null
          id?: number
          inicio_do_contrato?: string | null
          mensalidade_fee?: number | null
          nome?: string | null
          orcamento_mensal?: number | null
          preco_do_lead_15d?: number | null
          preco_do_lead_3d?: number | null
          preco_do_lead_7d?: number | null
          prioridade?: Database["public"]["Enums"]["Prioridade"] | null
          responsavel?: Json | null
          status?: Database["public"]["Enums"]["Status"]
          ultimo_envio?: string | null
        }
        Update: {
          ad_acc_id?: number | null
          cidade?: string | null
          cnpj?: number | null
          cobranca_meta?: Database["public"]["Enums"]["Cobrança Meta"] | null
          created_at?: string
          creditos?: number | null
          estado?: string | null
          fim_do_contrato?: string | null
          id?: number
          inicio_do_contrato?: string | null
          mensalidade_fee?: number | null
          nome?: string | null
          orcamento_mensal?: number | null
          preco_do_lead_15d?: number | null
          preco_do_lead_3d?: number | null
          preco_do_lead_7d?: number | null
          prioridade?: Database["public"]["Enums"]["Prioridade"] | null
          responsavel?: Json | null
          status?: Database["public"]["Enums"]["Status"]
          ultimo_envio?: string | null
        }
        Relationships: []
      }
      dados_importantes: {
        Row: {
          data: string | null
          id: number
          key: string
        }
        Insert: {
          data?: string | null
          id?: number
          key: string
        }
        Update: {
          data?: string | null
          id?: number
          key?: string
        }
        Relationships: []
      }
      membros_unidade: {
        Row: {
          cliente_id: number | null
          email: string | null
          funcao: string | null
          id: number
          nome: string
          telefone: string | null
        }
        Insert: {
          cliente_id?: number | null
          email?: string | null
          funcao?: string | null
          id?: number
          nome: string
          telefone?: string | null
        }
        Update: {
          cliente_id?: number | null
          email?: string | null
          funcao?: string | null
          id?: number
          nome?: string
          telefone?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "membros_unidade_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      usuarios: {
        Row: {
          cpf: string
          created_at: string
          email: string
          id: string
          nivel_acesso: string
          nome: string
          updated_at: string
        }
        Insert: {
          cpf: string
          created_at?: string
          email: string
          id?: string
          nivel_acesso: string
          nome: string
          updated_at?: string
        }
        Update: {
          cpf?: string
          created_at?: string
          email?: string
          id?: string
          nivel_acesso?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      "Cobrança Meta": "Boleto" | "Cartão" | "Não faz trafego"
      Prioridade: "Baixo" | "Médio" | "Alto" | "Quarentena"
      Status:
        | "Fechado"
        | "Onboarding"
        | "Ativo"
        | "Desligamento Programado"
        | "Desistente"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
