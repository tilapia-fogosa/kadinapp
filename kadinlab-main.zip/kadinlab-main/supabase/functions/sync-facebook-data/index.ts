
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || '';
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

async function getFacebookToken() {
  console.log("Buscando token do Facebook...");
  const { data, error } = await supabase
    .from('dados_importantes')
    .select('data')
    .eq('key', 'meta_access_token')
    .single();

  if (error) {
    console.error("Erro ao buscar token:", error);
    throw error;
  }
  return data.data;
}

async function getClientesAtivos() {
  console.log("Buscando clientes ativos...");
  const { data, error } = await supabase
    .from('clientes')
    .select('*')
    .eq('status', 'Ativo');

  if (error) {
    console.error("Erro ao buscar clientes:", error);
    throw error;
  }

  console.log(`Total de clientes ativos encontrados: ${data.length}`);
  
  // Listar clientes encontrados
  data.forEach(cliente => {
    console.log(`Cliente: ${cliente.nome}, ID: ${cliente.id}, Ad Account: ${cliente.ad_acc_id}, Cobrança: ${cliente.cobranca_meta}`);
  });
  
  return data;
}

async function getFacebookAdAccountData(accountId: string, token: string) {
  console.log(`Buscando dados da conta ${accountId} no Facebook...`);
  const url = `https://graph.facebook.com/v19.0/act_${accountId}`;
  const params = new URLSearchParams({
    access_token: token,
    fields: 'name,account_status,balance,spend_cap,amount_spent'
  });

  try {
    const response = await fetch(`${url}?${params}`);
    const responseText = await response.text(); // Primeiro pegamos o texto da resposta
    
    if (!response.ok) {
      console.error(`Erro na resposta do Facebook para conta ${accountId}:`, responseText);
      throw new Error(`Erro ao buscar dados da conta ${accountId}: ${response.statusText}`);
    }
    
    try {
      const data = JSON.parse(responseText); // Depois tentamos fazer o parse
      console.log(`Dados recebidos do Facebook para conta ${accountId}:`, data);
      return data;
    } catch (e) {
      console.error(`Erro ao fazer parse dos dados do Facebook para conta ${accountId}:`, e);
      throw new Error(`Resposta inválida do Facebook para conta ${accountId}`);
    }
  } catch (error) {
    console.error(`Erro ao fazer requisição para conta ${accountId}:`, error);
    throw error;
  }
}

async function updateClienteCreditos(id: number, creditos: number, ultimo_envio: string) {
  // Garantir que créditos nunca seja null, usar 0 como valor mínimo
  const creditosFinais = Math.max(0, creditos);
  
  console.log(`Atualizando cliente ${id}:
    Créditos originais: ${creditos}
    Créditos finais: ${creditosFinais}
    Último envio: ${ultimo_envio}
  `);
  
  const { error } = await supabase
    .from('clientes')
    .update({ 
      creditos: creditosFinais,
      ultimo_envio: ultimo_envio
    })
    .eq('id', id);

  if (error) {
    console.error(`Erro ao atualizar cliente ${id}:`, error);
    throw error;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("=== Iniciando sincronização ===");
    
    const facebookToken = await getFacebookToken();
    console.log("Token do Facebook obtido com sucesso");
    
    const clientes = await getClientesAtivos();
    
    const resultados = {
      total: clientes.length,
      processados: 0,
      erros: 0,
      detalhes: [] as string[]
    };
    
    for (const cliente of clientes) {
      console.log(`\n=== Processando cliente: ${cliente.nome} ===`);
      
      // Validar dados do cliente
      if (!cliente.ad_acc_id) {
        console.log(`${cliente.nome}: Sem conta de anúncios configurada (ad_acc_id está vazio)`);
        resultados.detalhes.push(`${cliente.nome}: Sem conta de anúncios configurada`);
        continue;
      }

      if (!cliente.cobranca_meta) {
        console.log(`${cliente.nome}: Tipo de cobrança não configurado`);
        resultados.detalhes.push(`${cliente.nome}: Tipo de cobrança não configurado`);
        continue;
      }

      try {
        const adAccountData = await getFacebookAdAccountData(cliente.ad_acc_id.toString(), facebookToken);
        
        if (cliente.cobranca_meta === 'Boleto') {
          if (typeof adAccountData.spend_cap === 'undefined') {
            console.log(`${cliente.nome}: Conta sem limite de gastos configurado no Facebook`);
            resultados.detalhes.push(`${cliente.nome}: Conta sem limite de gastos configurado`);
            continue;
          }

          if (typeof adAccountData.amount_spent === 'undefined') {
            console.log(`${cliente.nome}: Não foi possível obter o gasto atual da conta`);
            resultados.detalhes.push(`${cliente.nome}: Erro ao obter gasto atual`);
            continue;
          }

          const creditos = adAccountData.spend_cap - adAccountData.amount_spent;
          console.log(`${cliente.nome}: 
            Limite de gastos: ${adAccountData.spend_cap}
            Gasto atual: ${adAccountData.amount_spent}
            Créditos calculados: ${creditos}
          `);
          
          await updateClienteCreditos(
            cliente.id, 
            creditos / 100, // Convertendo de centavos para reais
            new Date().toISOString()
          );
          
          console.log(`${cliente.nome}: Atualizado com sucesso`);
          resultados.processados++;
          resultados.detalhes.push(`${cliente.nome}: Atualizado com sucesso`);
        } else {
          console.log(`${cliente.nome}: Ignorado (não é boleto)`);
          resultados.detalhes.push(`${cliente.nome}: Ignorado (não é boleto)`);
        }
      } catch (error) {
        console.error(`Erro ao processar ${cliente.nome}:`, error);
        resultados.erros++;
        resultados.detalhes.push(`${cliente.nome}: Erro - ${error.message}`);
      }
    }

    console.log("\n=== Sincronização concluída ===");
    console.log("Resultados:", resultados);

    return new Response(
      JSON.stringify({ 
        message: 'Sincronização concluída com sucesso',
        resultados 
      }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    );

  } catch (error) {
    console.error('Erro durante a sincronização:', error);
    return new Response(
      JSON.stringify({ error: error.message }), 
      { 
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  }
});
